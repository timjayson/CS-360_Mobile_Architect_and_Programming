package com.example.timjaysoninventoryapp;

import android.os.Bundle;

// This allows the application to move between screens.
import android.content.Intent;

// This allows Java code to interact with button controls.
import android.widget.Button;

// This allows Java code to read text entered by the user.
import android.widget.EditText;

// This allows Java code to update text displayed on the screen.
import android.widget.TextView;

// This displays short popup messages to the user.
import android.widget.Toast;

// This gives access to Android permission constants such as SEND_SMS.
import android.Manifest;

// This checks whether the app currently has a permission.
import android.content.pm.PackageManager;

// This allows the app to request permissions at runtime.
import androidx.core.app.ActivityCompat;

// This checks permission status in a compatible way.
import androidx.core.content.ContextCompat;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class SmsNotificationActivity extends AppCompatActivity {

    // This button allows the user to enable SMS notifications.
    private Button allowButton;

    // This button allows the user to disable SMS notifications.
    private Button declineButton;

    // This button updates the stored phone number.
    private Button updatePhoneButton;

    // This button returns the user to the inventory screen.
    private Button returnButton;

    // This displays the current SMS permission status.
    private TextView permissionStatusTextView;

    // This displays the currently saved phone number.
    private TextView phoneNumberTextView;

    // This allows the user to enter a new phone number.
    private EditText phoneNumberEditText;

    // This stores whether SMS notifications are enabled.
    private boolean smsAllowed = false;

    // This stores the current phone number.
    private String phoneNumber = "1234567890";

    // This number identifies the SMS permission request.
    private static final int SMS_PERMISSION_REQUEST_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // This enables edge-to-edge display support.
        EdgeToEdge.enable(this);

        // This loads the SMS notification layout.
        setContentView(R.layout.activity_sms_notification);

        // This connects the Allow button to the layout.
        allowButton = findViewById(R.id.button8);

        // This connects the Decline button to the layout.
        declineButton = findViewById(R.id.button9);

        // This connects the Update Phone Number button to the layout.
        updatePhoneButton = findViewById(R.id.button10);

        // This connects the Return to Inventory button to the layout.
        returnButton = findViewById(R.id.button11);

        // This connects the permission status TextView.
        permissionStatusTextView = findViewById(R.id.textView25);

        // This connects the phone number TextView.
        phoneNumberTextView = findViewById(R.id.textView30);

        // This connects the phone number EditText.
        phoneNumberEditText = findViewById(R.id.editTextNumber3);

        // This runs when the Allow button is pressed.
        allowButton.setOnClickListener(v -> {

            // This checks whether SMS permission has already been granted.
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                // This requests SMS permission from Android.
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_REQUEST_CODE
                );

            } else {

                // Permission is already granted.
                smsAllowed = true;

                permissionStatusTextView.setText("Permission granted");

                Toast.makeText(
                        this,
                        "SMS notifications allowed.",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

        // This runs when the Decline button is pressed.
        declineButton.setOnClickListener(v -> {

            // This disables SMS notifications.
            smsAllowed = false;

            // This updates the permission status displayed on the screen.
            permissionStatusTextView.setText("Permission denied");

            // This informs the user that SMS notifications are disabled.
            Toast.makeText(
                    this,
                    "The app will continue without SMS notifications.",
                    Toast.LENGTH_SHORT
            ).show();
        });

        // This runs when the Update Phone Number button is pressed.
        updatePhoneButton.setOnClickListener(v -> {

            // This gets the phone number entered by the user.
            String enteredNumber =
                    phoneNumberEditText.getText().toString().trim();

            // This checks whether a phone number was entered.
            if (enteredNumber.isEmpty()) {

                Toast.makeText(
                        this,
                        "Please enter a phone number.",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            // This saves the new phone number.
            phoneNumber = enteredNumber;

            // This updates the displayed phone number.
            phoneNumberTextView.setText(
                    "Current phone number: " + phoneNumber
            );

            // This clears the text box after the number is saved.
            phoneNumberEditText.setText("");

            // This informs the user that the phone number was updated.
            Toast.makeText(
                    this,
                    "Phone number updated.",
                    Toast.LENGTH_SHORT
            ).show();
        });

        // This runs when the Return to Inventory button is pressed.
        returnButton.setOnClickListener(v -> {

            // This creates an intent that opens the inventory screen.
            Intent intent =
                    new Intent(
                            SmsNotificationActivity.this,
                            InventoryActivity.class
                    );

            // This opens the inventory screen.
            startActivity(intent);
        });
    }

    // This runs after the user responds to the permission request.
    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
        );

        // This checks whether the response belongs to the SMS permission request.
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {

            // This checks whether permission was granted.
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                smsAllowed = true;

                permissionStatusTextView.setText("Permission granted");

                Toast.makeText(
                        this,
                        "SMS permission granted.",
                        Toast.LENGTH_SHORT
                ).show();

            } else {

                smsAllowed = false;

                permissionStatusTextView.setText("Permission denied");

                Toast.makeText(
                        this,
                        "The app will continue without SMS notifications.",
                        Toast.LENGTH_SHORT
                ).show();
            }
        }
    }
}