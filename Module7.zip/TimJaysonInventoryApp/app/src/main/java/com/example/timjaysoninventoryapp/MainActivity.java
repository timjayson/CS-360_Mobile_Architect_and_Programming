package com.example.timjaysoninventoryapp;

import android.os.Bundle;

// This allows the application to move from one screen to another.
import android.content.Intent;

// This allows Java code to interact with button controls.
import android.widget.Button;

// This allows Java code to read text entered by the user.
import android.widget.EditText;

// This displays short popup messages to the user.
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    // This is the username text box from the login screen.
    private EditText usernameEditText;

    // This is the password text box from the login screen.
    private EditText passwordEditText;

    // This is the login button.
    private Button loginButton;

    // This is the Create Account button.
    private Button createAccountButton;

    // This is the Forgot Password button.
    private Button forgotPasswordButton;

    // This is the database object used to access login information.
    private LoginInfo loginInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // This connects the username variable to the username text box in the layout.
        usernameEditText = findViewById(R.id.editTextText);

        // This connects the password variable to the password text box in the layout.
        passwordEditText = findViewById(R.id.editTextTextPassword);

        // This connects the loginButton variable to the Login button in the layout.
        loginButton = findViewById(R.id.button);

        // This connects the createAccountButton variable to the Create Account button in the layout.
        createAccountButton = findViewById(R.id.button2);

        // This connects the forgotPasswordButton variable to the Forgot Password button in the layout.
        forgotPasswordButton = findViewById(R.id.button3);

        // This creates the LoginInfo database object.
        loginInfo = new LoginInfo(this);

        // This runs createAccount() when the Create Account button is pressed.
        createAccountButton.setOnClickListener(v -> createAccount());

        // This runs loginUser() when the Login button is pressed.
        loginButton.setOnClickListener(v -> loginUser());

        // This displays a message when the Forgot Password button is pressed.
        forgotPasswordButton.setOnClickListener(v ->
                Toast.makeText(
                        this,
                        "Password recovery is not currently available.",
                        Toast.LENGTH_SHORT
                ).show()
        );
    }

    // This method creates a new user account using the information entered by the user.
    private void createAccount() {

        // This gets the username entered by the user.
        String username = usernameEditText.getText().toString().trim();

        // This gets the password entered by the user.
        String password = passwordEditText.getText().toString().trim();

        // This checks that both fields contain information.
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter a username and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        // This attempts to create the user account in the database.
        boolean created = loginInfo.createUser(username, password);

        if (created) {
            Toast.makeText(this, "Account created successfully.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Username already exists.", Toast.LENGTH_SHORT).show();
        }
    }
    // This method checks the username and password entered by the user.
    private void loginUser() {

        // This gets the username entered by the user.
        String username = usernameEditText.getText().toString().trim();

        // This gets the password entered by the user.
        String password = passwordEditText.getText().toString().trim();

        // This checks that both fields contain information.
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter a username and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        // This checks the username and password against the saved database information.
        boolean validLogin = loginInfo.checkUser(username, password);

        if (validLogin) {
            Toast.makeText(this, "Login successful.", Toast.LENGTH_SHORT).show();

            // This moves the user from the login screen to the inventory screen.
            Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
            startActivity(intent);

        } else {
            Toast.makeText(this, "Invalid username or password.", Toast.LENGTH_SHORT).show();
        }
    }
}