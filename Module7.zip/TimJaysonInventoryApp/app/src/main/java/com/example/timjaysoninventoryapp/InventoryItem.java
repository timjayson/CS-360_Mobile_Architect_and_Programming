package com.example.timjaysoninventoryapp;

// This class represents one inventory item from the database.
public class InventoryItem {

    // This stores the database ID for the item.
    private int id;

    // This stores the item's name.
    private String itemName;

    // This stores the item's quantity.
    private int quantity;

    // This stores the item's location.
    private String location;

    // This constructor creates an InventoryItem object.
    public InventoryItem(int id, String itemName, int quantity, String location) {
        this.id = id;
        this.itemName = itemName;
        this.quantity = quantity;
        this.location = location;
    }

    // This returns the item's database ID.
    public int getId() {
        return id;
    }

    // This returns the item's name.
    public String getItemName() {
        return itemName;
    }

    // This returns the item's quantity.
    public int getQuantity() {
        return quantity;
    }

    // This returns the item's location.
    public String getLocation() {
        return location;
    }
}