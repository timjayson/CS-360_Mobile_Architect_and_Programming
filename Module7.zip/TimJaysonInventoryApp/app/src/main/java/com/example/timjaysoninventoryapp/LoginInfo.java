package com.example.timjaysoninventoryapp;

// Importing context gives access to application resources and services.
import android.content.Context;

// The cursor allows the app to read the results returned from a database query.
import android.database.Cursor;

// This allows the application to read, write, and delete information stored in SQLite.
import android.database.sqlite.SQLiteDatabase;

// This provides methods for creating, opening, and updating databases.
import android.database.sqlite.SQLiteOpenHelper;

// This class manages all database creation and maintenance for the Inventory Manager application.
public class LoginInfo extends SQLiteOpenHelper {

    // This is the SQLite database file that Android creates.
    private static final String DATABASE_NAME = "inventory_app.db";

    // Database version number that is increased whenever the database structure changes.
    private static final int DATABASE_VERSION = 2;

    // The constructor runs when a LoginInfo object is created.
    // If the database does not exist, Android will automatically call the onCreate() method.
    public LoginInfo(Context context) {

        // This calls the parent SQLiteOpenHelper constructor.
        super(
                context,
                DATABASE_NAME,
                null,
                DATABASE_VERSION
        );
    }

    /*
     * This method executes automatically the very first time the application accesses the database.
     * It is responsible for creating all required tables.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {

        // This creates the users table.
        db.execSQL(
                "CREATE TABLE users (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT UNIQUE, " +
                        "password TEXT)"
        );

        // This creates the inventory table.
        db.execSQL(
                "CREATE TABLE inventory (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "item_name TEXT, " +
                        "quantity INTEGER, " +
                        "location TEXT)"
        );
    }

    // Android automatically calls this method whenever database version is increased.
    @Override
    public void onUpgrade(SQLiteDatabase db,
                          int oldVersion,
                          int newVersion) {

        // This removes the existing users table if it exists.
        db.execSQL("DROP TABLE IF EXISTS users");

        // This removes the existing inventory table if it exists.
        db.execSQL("DROP TABLE IF EXISTS inventory");

        // This rebuilds the database using the latest structure.
        onCreate(db);
    }

    // This method creates a new user account and saves it in the users table.
    public boolean createUser(String username, String password) {

        // This opens the database so information can be written to it.
        SQLiteDatabase db = this.getWritableDatabase();

        try {

            // This inserts the username and password into the users table.
            db.execSQL(
                    "INSERT INTO users (username, password) VALUES (?, ?)",
                    new Object[]{username, password}
            );

            // This returns true if the account was created successfully.
            return true;

        } catch (Exception e) {

            // This returns false if the username already exists or the insert fails.
            return false;
        }
    }

    // This method checks whether the entered username and password match a saved user.
    public boolean checkUser(String username, String password) {

        // This opens the database so information can be read from it.
        SQLiteDatabase db = this.getReadableDatabase();

        // This searches for a user with the matching username and password.
        Cursor cursor = db.rawQuery(
                "SELECT * FROM users WHERE username = ? AND password = ?",
                new String[]{username, password}
        );

        // If the cursor finds at least one row, the login information is valid.
        boolean userExists = cursor.getCount() > 0;

        // This closes the cursor to release database resources.
        cursor.close();

        // This returns whether the user was found.
        return userExists;
    }

    // This method adds a new inventory item to the inventory table.
    public boolean addInventoryItem(String itemName,
                                    int quantity,
                                    String location) {

        // This opens the database so information can be written to it.
        SQLiteDatabase db = this.getWritableDatabase();

        try {

            // This inserts the inventory item into the inventory table.
            db.execSQL(
                    "INSERT INTO inventory (item_name, quantity, location) VALUES (?, ?, ?)",
                    new Object[]{itemName, quantity, location}
            );

            // This returns true if the item was added successfully.
            return true;

        } catch (Exception e) {

            // This returns false if an error occurs.
            return false;
        }
    }

    // This method gets all inventory items from the inventory table.
    public Cursor getAllInventoryItems() {

        // Open the database so information can be read from it.
        SQLiteDatabase db = this.getReadableDatabase();

        // Return all rows from the inventory table.
        return db.rawQuery(
                "SELECT id, item_name, quantity, location FROM inventory ORDER BY id DESC",
                null
        );
    }

    // This method deletes an inventory item using its database ID.
    public boolean deleteInventoryItem(int id) {

        // This opens the database so information can be deleted.
        SQLiteDatabase db = this.getWritableDatabase();

        try {
            // This deletes the inventory item that matches the selected ID.
            db.execSQL(
                    "DELETE FROM inventory WHERE id = ?",
                    new Object[]{id}
            );

            // This returns true if the delete command runs.
            return true;

        } catch (Exception e) {

            // This returns false if an error occurs.
            return false;
        }
    }

    // This method updates an existing inventory item using its database ID.
    public boolean updateInventoryItem(int id, String itemName, int quantity, String location) {

        // This opens the database so information can be updated.
        SQLiteDatabase db = this.getWritableDatabase();

        try {
            // This updates the inventory item that matches the selected ID.
            db.execSQL(
                    "UPDATE inventory SET item_name = ?, quantity = ?, location = ? WHERE id = ?",
                    new Object[]{itemName, quantity, location, id}
            );

            // This returns true if the update command runs.
            return true;

        } catch (Exception e) {

            // This returns false if an error occurs.
            return false;
        }
    }
}