package com.example.timjaysoninventoryapp;

// This allows the adapter to create layout objects from XML files.
import android.view.LayoutInflater;

// This represents a visual component displayed on the screen.
import android.view.View;

// This is the parent container that will hold the RecyclerView rows.
import android.view.ViewGroup;

// This allows Java code to update text displayed on the screen.
import android.widget.TextView;

// This allows Java code to interact with button controls.
import android.widget.Button;

// This is used to display a scrolling list of inventory items.
import androidx.recyclerview.widget.RecyclerView;

// This stores multiple inventory items in memory.
import java.util.ArrayList;

// This adapter connects inventory data from the database to the RecyclerView.
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {

    // This stores all inventory items that will be displayed.
    private ArrayList<InventoryItem> inventoryItems;

    // This stores the delete button listener used by each inventory row.
    private OnDeleteClickListener deleteClickListener;

    // This stores the update button listener used by each inventory row.
    private OnUpdateClickListener updateClickListener;

    // This interface defines what happens when a Delete button is pressed.
    public interface OnDeleteClickListener {

        // This method runs when the user clicks a Delete button.
        void onDeleteClick(InventoryItem item);
    }

    // This interface defines what happens when an Update button is pressed.
    public interface OnUpdateClickListener {

        // This method runs when the user clicks an Update button.
        void onUpdateClick(InventoryItem item);
    }

    // This constructor creates an InventoryAdapter object.
    public InventoryAdapter(
            ArrayList<InventoryItem> inventoryItems,
            OnDeleteClickListener deleteClickListener,
            OnUpdateClickListener updateClickListener
    ) {

        // This saves the inventory item list.
        this.inventoryItems = inventoryItems;

        // This saves the delete button listener.
        this.deleteClickListener = deleteClickListener;

        // This saves the update button listener.
        this.updateClickListener = updateClickListener;
    }

    // This method creates a new row when RecyclerView needs one.
    @Override
    public InventoryViewHolder onCreateViewHolder(
            ViewGroup parent,
            int viewType
    ) {

        // This creates a row using the inventory_row.xml layout file.
        View view = LayoutInflater
                .from(parent.getContext())
                .inflate(
                        R.layout.inventory_row,
                        parent,
                        false
                );

        // This returns the completed row.
        return new InventoryViewHolder(view);
    }

    // This method places inventory data into each row.
    @Override
    public void onBindViewHolder(
            InventoryViewHolder holder,
            int position
    ) {

        // This gets the inventory item for the current row.
        InventoryItem item = inventoryItems.get(position);

        // This displays the item name.
        holder.itemNameTextView.setText(item.getItemName());

        // This displays the quantity.
        holder.quantityTextView.setText(
                String.valueOf(item.getQuantity())
        );

        // This displays the location.
        holder.locationTextView.setText(item.getLocation());

        // This runs the update action when the Update button is pressed.
        holder.updateButton.setOnClickListener(
                v -> updateClickListener.onUpdateClick(item)
        );

        // This runs the delete action when the Delete button is pressed.
        holder.deleteButton.setOnClickListener(
                v -> deleteClickListener.onDeleteClick(item)
        );
    }

    // This returns the total number of inventory items.
    @Override
    public int getItemCount() {

        return inventoryItems.size();
    }

    // This class stores references to the controls inside each RecyclerView row.
    public static class InventoryViewHolder extends RecyclerView.ViewHolder {

        // This displays the inventory item name.
        TextView itemNameTextView;

        // This displays the inventory quantity.
        TextView quantityTextView;

        // This displays the inventory location.
        TextView locationTextView;

        // This is the Update button for the row.
        Button updateButton;

        // This is the Delete button for the row.
        Button deleteButton;

        // This constructor connects the Java variables to the row layout controls.
        public InventoryViewHolder(View itemView) {
            super(itemView);

            // This connects the item name TextView.
            itemNameTextView =
                    itemView.findViewById(R.id.textRowItemName);

            // This connects the quantity TextView.
            quantityTextView =
                    itemView.findViewById(R.id.textRowQuantity);

            // This connects the location TextView.
            locationTextView =
                    itemView.findViewById(R.id.textRowLocation);

            // This connects the Update button.
            updateButton =
                    itemView.findViewById(R.id.buttonRowUpdate);

            // This connects the Delete button.
            deleteButton =
                    itemView.findViewById(R.id.buttonRowDelete);
        }
    }
}