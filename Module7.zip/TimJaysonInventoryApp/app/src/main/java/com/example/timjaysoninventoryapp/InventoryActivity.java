package com.example.timjaysoninventoryapp;

import android.os.Bundle;
// This allows this screen to move to the SMS settings screen.
import android.content.Intent;

// This allows Java code to interact with buttons.
import android.widget.Button;

// This allows Java code to read text entered by the user.
import android.widget.EditText;

// This displays short popup messages to the user.
import android.widget.Toast;

// This displays a scrolling list of inventory items.
import androidx.recyclerview.widget.RecyclerView;

// This arranges RecyclerView items in a vertical list.
import androidx.recyclerview.widget.LinearLayoutManager;

// This stores multiple inventory items in memory.
import java.util.ArrayList;

// This allows this activity to read rows returned from the database.
import android.database.Cursor;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class InventoryActivity extends AppCompatActivity {

    // This is the text box for the item name.
    private EditText itemNameEditText;

    // This is the text box for the item quantity.
    private EditText quantityEditText;

    // This is the text box for the item location.
    private EditText locationEditText;

    // This is the button used to add an inventory item.
    private Button addItemButton;

    // This is the button used to open SMS notification settings.
    private Button smsSettingsButton;

    // This is the database object used to save inventory information.
    private LoginInfo loginInfo;

    // This is the RecyclerView used to display inventory items.
    private RecyclerView recyclerInventory;

    // This adapter connects inventory data to the RecyclerView.
    private InventoryAdapter inventoryAdapter;

    // This stores all inventory items currently displayed.
    private ArrayList<InventoryItem> inventoryItems;

    // This stores the ID of the item currently being updated.
    // A value of -1 means the app is adding a new item instead.
    private int selectedItemId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inventory);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // This connects the itemNameEditText variable to the item name text box in the layout.
        itemNameEditText = findViewById(R.id.editTextText2);

        // This connects the quantityEditText variable to the item quantity text box in the layout.
        quantityEditText = findViewById(R.id.editTextNumber);

        // This connects the locationEditText variable to the item location text box in the layout.
        locationEditText = findViewById(R.id.editTextText4);

        // This connects the addItemButton variable to the Add Item button in the layout.
        addItemButton = findViewById(R.id.button7);

        // This connects the smsSettingsButton variable to the SMS notification settings button.
        smsSettingsButton = findViewById(R.id.button12);

        // This creates the LoginInfo database object.
        loginInfo = new LoginInfo(this);

        // This connects the RecyclerView variable to the RecyclerView in the layout.
        recyclerInventory = findViewById(R.id.recyclerViewInventory);

        // This creates the ArrayList that will store inventory items.
        inventoryItems = new ArrayList<>();

        // This arranges the RecyclerView items in a vertical list.
        recyclerInventory.setLayoutManager(new LinearLayoutManager(this));

        //This deletes the item in the row
        inventoryAdapter = new InventoryAdapter(
                inventoryItems,

                item -> {
                    boolean deleted = loginInfo.deleteInventoryItem(item.getId());

                    if (deleted) {
                        Toast.makeText(this, "Item deleted.", Toast.LENGTH_SHORT).show();
                        loadInventoryItems();
                    } else {
                        Toast.makeText(this, "Item could not be deleted.", Toast.LENGTH_SHORT).show();
                    }
                },

                item -> {
                    selectedItemId = item.getId();

                    itemNameEditText.setText(item.getItemName());
                    quantityEditText.setText(String.valueOf(item.getQuantity()));
                    locationEditText.setText(item.getLocation());

                    Toast.makeText(this, "Edit the fields, then press Add item to save changes.", Toast.LENGTH_LONG).show();
                }
        );

        // This connects the adapter to the RecyclerView.
        recyclerInventory.setAdapter(inventoryAdapter);

        // This loads saved inventory items when the screen opens.
        loadInventoryItems();

        // This runs addInventoryItem() when the Add Item button is pressed.
        addItemButton.setOnClickListener(v -> addInventoryItem());

        // This opens the SMS notification settings screen.
        smsSettingsButton.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, SmsNotificationActivity.class);
            startActivity(intent);
        });
    }
    // This method adds a new inventory item using the information entered by the user.
    private void addInventoryItem() {

        // This gets the item name entered by the user.
        String itemName = itemNameEditText.getText().toString().trim();

        // This gets the quantity entered by the user as text.
        String quantityText = quantityEditText.getText().toString().trim();

        // This gets the location entered by the user.
        String location = locationEditText.getText().toString().trim();

        // This checks that all fields contain information.
        if (itemName.isEmpty() || quantityText.isEmpty() || location.isEmpty()) {
            Toast.makeText(this, "Please enter item name, quantity, and location.", Toast.LENGTH_SHORT).show();
            return;
        }

        // This converts the quantity from text into a number.
        int quantity = Integer.parseInt(quantityText);

        // Check whether the user is adding a new item or updating an existing item.
        if (selectedItemId == -1) {

            // This attempts to save the new inventory item in the database.
            boolean added = loginInfo.addInventoryItem(itemName, quantity, location);

            if (added) {
                Toast.makeText(this, "Inventory item added.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Item could not be added.", Toast.LENGTH_SHORT).show();
                return;
            }

        } else {

            // This attempts to update the selected inventory item in the database.
            boolean updated = loginInfo.updateInventoryItem(selectedItemId, itemName, quantity, location);

            if (updated) {
                Toast.makeText(this, "Inventory item updated.", Toast.LENGTH_SHORT).show();

                // Reset selectedItemId so the next button press adds a new item.
                selectedItemId = -1;

            } else {
                Toast.makeText(this, "Item could not be updated.", Toast.LENGTH_SHORT).show();
                return;
            }
        }

    // This refreshes the RecyclerView after adding or updating an item.
        loadInventoryItems();

    // This clears the text boxes after the item is saved.
        itemNameEditText.setText("");
        quantityEditText.setText("");
        locationEditText.setText("");
    }
    // This method loads all inventory items from the database into the RecyclerView.
    private void loadInventoryItems() {

        // This clears the current list so duplicate items are not displayed.
        inventoryItems.clear();

        // This gets all inventory items from the database.
        Cursor cursor = loginInfo.getAllInventoryItems();

        // This loops through every inventory item returned by the database.
        while (cursor.moveToNext()) {

            // This gets each value from the current database row.
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String itemName = cursor.getString(cursor.getColumnIndexOrThrow("item_name"));
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));
            String location = cursor.getString(cursor.getColumnIndexOrThrow("location"));

            // This creates an InventoryItem object using the database values.
            InventoryItem item = new InventoryItem(id, itemName, quantity, location);

            // This adds the item to the list shown by RecyclerView.
            inventoryItems.add(item);
        }

        // This closes the cursor after reading the database results.
        cursor.close();

        // This tells the adapter that the list has changed.
        inventoryAdapter.notifyDataSetChanged();
    }
}